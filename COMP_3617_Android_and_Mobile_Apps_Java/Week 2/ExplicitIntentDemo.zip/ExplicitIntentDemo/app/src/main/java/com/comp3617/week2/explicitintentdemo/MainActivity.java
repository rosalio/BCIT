package com.comp3617.week2.explicitintentdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_CODE = 100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void launchSecondActivity(View v) {
        Intent i = new Intent(this, SecondActivity.class);
        i.putExtra("MSG", "Hello Second Activity!");
        //startActivity(i);
        startActivityForResult(i, REQUEST_CODE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
            if (requestCode == REQUEST_CODE) {
                String msg = data.getStringExtra("REPLY");
                Toast.makeText(this, "Msg " + msg, Toast.LENGTH_LONG).show();
            }
    }
}
