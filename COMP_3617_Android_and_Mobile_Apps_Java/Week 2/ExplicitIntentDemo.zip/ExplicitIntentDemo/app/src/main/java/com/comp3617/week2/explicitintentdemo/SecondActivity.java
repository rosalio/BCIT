package com.comp3617.week2.explicitintentdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent i = getIntent();
        if (i != null) {
             String msg = i.getStringExtra("MSG");
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        }
    }


    public void onClick(View v){
        Intent i = new Intent();
        i.putExtra("REPLY", "Hello Main Activity!");
        setResult(Activity.RESULT_OK, i);
        finish();
    }
}
