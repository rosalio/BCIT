package com.comp3617.week4.buttondemos;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         if (savedInstanceState != null) {
             count = savedInstanceState.getInt("counter");
         }

    }


    public void onClick(View v) {
        CheckBox cbExpressDelivery = (CheckBox)v;

        String msg = cbExpressDelivery.isChecked()? "Express Delivery" : "Regular Post";
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    public void onRadioButtonClicked(View v) {
        String msg = null;
        int id = v.getId();
        if (id == R.id.rbAB)
            msg = "AB";
        else if (id == R.id.rbBC)
            msg = "BC";
        else if (id == R.id.rbON)
            msg = "ON";

        Toast.makeText(this, msg + " is selected", Toast.LENGTH_LONG).show();
    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("counter", count);
    }
}
