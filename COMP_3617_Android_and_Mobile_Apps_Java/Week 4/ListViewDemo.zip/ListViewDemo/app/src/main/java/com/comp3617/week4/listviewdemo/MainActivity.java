package com.comp3617.week4.listviewdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView lvDemo;

    private List<String> data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        lvDemo = (ListView) findViewById(R.id.lvDemo);
        data = generateSomeDummyData();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,
                data);

        lvDemo.setAdapter(adapter);

        lvDemo.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = data.get(position);
                Toast.makeText(MainActivity.this, "Selected item : " + selectedItem, Toast.LENGTH_LONG).show();
            }
        });

        //Long click listener
        lvDemo.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = data.get(position);
                Toast.makeText(MainActivity.this, "Selected item : " + selectedItem, Toast.LENGTH_LONG).show();
                return false;
            }
        });

    }


    private static List<String> generateSomeDummyData()
    {
        ArrayList<String> list = new ArrayList<>();
        for(int i = 0; i <= 100; i++)
            list.add(String.format("Data : %d", i));

        return list;
    }


}
