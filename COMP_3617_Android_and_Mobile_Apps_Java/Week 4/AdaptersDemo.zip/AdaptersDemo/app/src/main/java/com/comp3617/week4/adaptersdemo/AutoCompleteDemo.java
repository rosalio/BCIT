package com.comp3617.week4.adaptersdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class AutoCompleteDemo extends AppCompatActivity {

    private AutoCompleteTextView actvCountries;
    private String[] countries;
    private String selectedCountry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auto_complete_demo);

        actvCountries = (AutoCompleteTextView) findViewById(R.id.actvCountries);

        countries = getResources().getStringArray(R.array.countries);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line,
                countries);

        actvCountries.setAdapter(adapter);

        actvCountries.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                selectedCountry = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }
}
