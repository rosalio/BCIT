package com.comp3617.week5.pickersdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.CalendarView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private CalendarView calView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calView = (CalendarView) findViewById(R.id.calView);

        calView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                Toast.makeText(MainActivity.this, String.format("%d-%d-%d", month, dayOfMonth, year), Toast.LENGTH_LONG).show();
            }
        });
    }
}
//Toast.makeText(MainActivity.this, String.format("%d-%d-%d", month, dayOfMonth, year), Toast.LENGTH_LONG).show();