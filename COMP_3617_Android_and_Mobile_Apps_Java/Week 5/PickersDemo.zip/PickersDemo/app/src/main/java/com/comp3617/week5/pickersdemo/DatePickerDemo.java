package com.comp3617.week5.pickersdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.DatePicker;
import android.widget.Toast;

import java.util.Calendar;

public class DatePickerDemo extends AppCompatActivity {

    private DatePicker dp;
    Calendar now = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_picker_demo);

        dp = (DatePicker) findViewById(R.id.datePicker);
        dp.init(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH),
                new DatePicker.OnDateChangedListener() {
                    @Override
                    public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        Toast.makeText(DatePickerDemo.this, String.format("%d-%d-%d", monthOfYear, dayOfMonth, year), Toast.LENGTH_LONG).show();
                        //Apply changes to the calendar object
                        now.set(Calendar.YEAR, year);
                        now.set(Calendar.MONTH, monthOfYear + 1);
                        now.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    }
                });
    }




}
