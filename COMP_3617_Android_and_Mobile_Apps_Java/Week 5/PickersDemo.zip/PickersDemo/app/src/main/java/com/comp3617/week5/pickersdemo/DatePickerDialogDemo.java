package com.comp3617.week5.pickersdemo;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class DatePickerDialogDemo extends AppCompatActivity {

    private Calendar now = Calendar.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_picker_dialog_demo);
    }

    public void onClick(View v) {
        if (v.getId() == R.id.btnDatePickerDialog) {
            //Show date picker dialog
            new DatePickerDialog(this, d, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show();
        }
        else if (v.getId() == R.id.btnTimePickerDialog) {
            //Show time picker dialog
            new TimePickerDialog(this, t, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show();
        }

        else if (v.getId() == R.id.btnAlertDialog){
            displayDialog();
        }
    }

    private void displayDialog() {
        AlertDialog.Builder bldr = new AlertDialog.Builder(this);

        bldr.setMessage("Make a selection");
        bldr.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(DatePickerDialogDemo.this, "Ok clicked", Toast.LENGTH_LONG).show();
            }
        });


        bldr.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(DatePickerDialogDemo.this, "Cancel clicked", Toast.LENGTH_LONG).show();
            }
        });

        AlertDialog dlg = bldr.create();

        //To show the dialog
        dlg.show();


    }


    private DatePickerDialog.OnDateSetListener d = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

        }
    };


    private TimePickerDialog.OnTimeSetListener t = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

        }
    };
}
