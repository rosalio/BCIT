package com.comp3617.week5.customlistdemo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by A00527696 on 2/18/2016.
 */
public class CustomListAdapter extends ArrayAdapter<Team> {

    private List<Team> teams;
    private Context ctx;

    public CustomListAdapter(Context context, List<Team> data) {
        super(context, R.layout.row_layout, data);
        teams = data;
        this.ctx = context;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        //Get team associated with position
        Team team = teams.get(position);

        LayoutInflater lf = LayoutInflater.from(ctx);
        //convert XML based row layout to a view

        View v = null;

        if (convertView != null)
            v = convertView; //Lets reuse the view
        else
            v = lf.inflate(R.layout.row_layout, parent, false); //construct a new view

        TextView tvTitle = (TextView)v.findViewById(R.id.teamTitle);
        TextView tvDescription = (TextView)v.findViewById(R.id.description);
        ImageView imageView = (ImageView)v.findViewById(R.id.imgTitle);

        tvTitle.setText(team.getTitle());
        tvDescription.setText(team.getDescription());
        imageView.setImageResource(R.drawable.nhl);


        return v;
    }
}
