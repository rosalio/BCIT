package com.comp3617.week5.customlistdemo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by A00527696 on 2/18/2016.
 */
public class Team {

    private String title;

    private String description;

    private int imageResource;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getImageResource() {
        return imageResource;
    }

    public void setImageResource(int imageResource) {
        this.imageResource = imageResource;
    }

    public static List<Team> NHL() {
        List<Team > teams = new ArrayList<Team>();
        Team canucks = new Team();
        canucks.setTitle("Canucks");
        canucks.setDescription("Vancouver based team");
        canucks.setImageResource(R.drawable.nhl);
        teams.add(canucks);

        Team ml = new Team();
        ml.setTitle("Maple Leafs");
        ml.setDescription("Toronto based team");
        ml.setImageResource(R.drawable.nhl);
        teams.add(ml);

        Team ds = new Team();
        ds.setTitle("Dallas Stars");
        ds.setDescription("Dallas based team");
        ds.setImageResource(R.drawable.nhl);
        teams.add(ds);

        Team ducks = new Team();
        ducks.setTitle("Ducks");
        ducks.setDescription("LA based team");
        ducks.setImageResource(R.drawable.nhl);
        teams.add(ducks);

        Team penguins = new Team();
        penguins.setTitle("Pengins");
        penguins.setDescription("Pittsburgh based team");
        penguins.setImageResource(R.drawable.nhl);
        teams.add(penguins);


        Team avalanche = new Team();
        avalanche.setTitle("Avalanche");
        avalanche.setDescription("Colarado based team");
        avalanche.setImageResource(R.drawable.nhl);
        teams.add(avalanche);

        Team canadiens = new Team();
        canadiens.setTitle("Canadiens");
        canadiens.setDescription("Montreal based team");
        canadiens.setImageResource(R.drawable.nhl);
        teams.add(avalanche);



        return teams;
    }
}
