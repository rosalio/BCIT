package com.comp3617.week5.customlistdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    private ListView lvTeams;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvTeams = (ListView)findViewById(R.id.lvTeams);

        //Construct an array adapter
        CustomListAdapter adapter = new CustomListAdapter(this, Team.NHL());

        lvTeams.setAdapter(adapter);
    }
}
