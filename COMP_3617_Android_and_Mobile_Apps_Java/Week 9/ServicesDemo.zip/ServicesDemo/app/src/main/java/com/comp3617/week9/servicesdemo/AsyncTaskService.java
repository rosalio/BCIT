package com.comp3617.week9.servicesdemo;

import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.IBinder;

public class AsyncTaskService extends Service {
    public AsyncTaskService() {
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        new AsyncTask<Intent, Void, Void>() {
            @Override
            protected Void doInBackground(Intent... params) {
                executeTask(params[0]);
                return null;
            }
        }.execute(intent);

        return START_NOT_STICKY;
    }

    void executeTask(Intent intent){
        //do some background work here....
    }

    @Override
    public IBinder onBind(Intent intent) {
       return null;
    }
}
