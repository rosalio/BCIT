package com.comp3617.week9.servicesdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    private static String LOG_TAG = BasicService.class.getName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(LOG_TAG, String.format("Activity Thread ID : %d", android.os.Process.myTid()));
    }

    public void onClick(View v){
        if (v.getId() == R.id.btnStartService) {
            Intent i = new Intent(this, BasicService.class);
            startService(i);
        }
        else if (v.getId() == R.id.btnStopService){
            Intent i = new Intent(this, BasicService.class);
            stopService(i);
        }
        else if (v.getId() == R.id.btnIntentService){
            Intent i = new Intent(this, SampleIntentService.class);
            startService(i);
        }

    }
}
