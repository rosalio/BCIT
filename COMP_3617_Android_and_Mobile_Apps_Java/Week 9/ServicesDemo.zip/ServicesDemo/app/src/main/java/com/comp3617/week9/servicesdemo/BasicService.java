package com.comp3617.week9.servicesdemo;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;


public class BasicService extends Service {
    private static String LOG_TAG = BasicService.class.getName();
    
    public BasicService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(LOG_TAG, "onCreate() of the service called");
        Log.d(LOG_TAG, String.format("Thread ID : %d", android.os.Process.myTid()));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(getApplicationContext(), "onStartCommand() called", Toast.LENGTH_LONG).show();

        //Do the work here....
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        Log.d(LOG_TAG, "onDestroy() of the service called");
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
            return null;
    }
}
