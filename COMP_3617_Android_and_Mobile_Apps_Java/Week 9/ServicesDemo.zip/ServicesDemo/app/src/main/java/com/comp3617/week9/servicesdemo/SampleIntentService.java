package com.comp3617.week9.servicesdemo;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;


public class SampleIntentService extends IntentService {

    private static String LOG_TAG = BasicService.class.getName();


    public SampleIntentService() {
        super("SampleIntentService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Log.d(LOG_TAG, String.format("SampleIntentService Thread ID : %d", android.os.Process.myTid()));
    }


}
