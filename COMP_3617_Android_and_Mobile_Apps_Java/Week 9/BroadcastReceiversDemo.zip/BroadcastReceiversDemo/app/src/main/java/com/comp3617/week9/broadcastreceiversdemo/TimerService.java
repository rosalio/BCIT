package com.comp3617.week9.broadcastreceiversdemo;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import java.util.Timer;
import java.util.TimerTask;

public class TimerService extends Service {
    private Timer timer;

    public TimerService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        setupTimerTask();
        return START_STICKY;
    }

    private void setupTimerTask() {
        if (timer == null) {
            timer = new Timer();
            TimerTask ts = new TimerTask() {
                @Override
                public void run() {
                    //This is where you want to perform an operation
                    Log.d("TimerTask", "This is sample output from a timer");
                }
            };

            timer.schedule(ts, 0, 5000L);
        }
    }

    @Override
    public void onDestroy() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
        super.onDestroy();
    }
}
