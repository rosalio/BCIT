package com.comp3617.week9.broadcastreceiversdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class COMP3617Receiver extends BroadcastReceiver {
    public COMP3617Receiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        //Start a service that does something based on a timer

        context.startService(new Intent(context, TimerService.class));
    }
}
