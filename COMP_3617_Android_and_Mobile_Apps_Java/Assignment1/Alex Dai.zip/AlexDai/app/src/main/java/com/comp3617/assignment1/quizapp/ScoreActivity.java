package com.comp3617.assignment1.quizapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ShareActionProvider;
import android.widget.TextView;

public class ScoreActivity extends Activity {

    private String totalScoreText;
    private TextView tvTotalScore;
    private Button btnRestart;

    private ShareActionProvider mShareActionProvider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);


        Intent intent = getIntent();
        totalScoreText = intent.getStringExtra("score");

        tvTotalScore = (TextView) findViewById(R.id.tvTotalScore);
        tvTotalScore.setText(totalScoreText);

        btnRestart = (Button) findViewById(R.id.btn_restart);
        btnRestart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               finish();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_item_share, menu);

        MenuItem item = menu.findItem(R.id.action_share);

        mShareActionProvider = (ShareActionProvider) item.getActionProvider();

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, "This is my score:" + totalScoreText);

        mShareActionProvider.setShareIntent(intent);

        startActivity(intent);

        return true;
    }
}
