package com.comp3617.assignment1.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView tvQuestion;
    private RadioGroup radioGroup;

    private RadioButton radioButton1;
    private RadioButton radioButton2;
    private RadioButton radioButton3;
    private RadioButton radioButton4;

    private Button btnStart;
    private Button btnNext;

    private int currentQuestionNum = 1;
    private String answer;
    private final int totalNumOfQuestions = 5;
    private int[] scoresheet = {0, 0, 0, 0, 0};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvQuestion = (TextView) findViewById(R.id.tv_question);
        radioGroup = (RadioGroup) findViewById(R.id.rg_options);
        radioButton1 = (RadioButton) findViewById(R.id.rb1);
        radioButton2 = (RadioButton) findViewById(R.id.rb2);
        radioButton3 = (RadioButton) findViewById(R.id.rb3);
        radioButton4 = (RadioButton) findViewById(R.id.rb4);
        btnStart = (Button) findViewById(R.id.btn_start);
        btnNext = (Button) findViewById(R.id.btn_next);

        showQuestion(currentQuestionNum);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton checkedRadioButton = (RadioButton) radioGroup.findViewById(checkedId);
                String checkedAnswer = checkedRadioButton.getText().toString();
                if (checkedAnswer.equals(answer)) {
                    scoresheet[currentQuestionNum - 1] = 1;
                } else {
                    scoresheet[currentQuestionNum - 1] = 0;
                }

//                String msg = "Score: " + calculateTotalScore();
//                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
            }
        });

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentQuestionNum = 1;
                resetScoresheet();
                showQuestion(currentQuestionNum);
//                String msg = "Score: " + calculateTotalScore();
//                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(!isRadioButtonChecked()) {
                    Toast.makeText(getApplicationContext(), "You must choose one answer!", Toast.LENGTH_SHORT).show();
                } else if (currentQuestionNum < totalNumOfQuestions) {
                    currentQuestionNum++;
                    showQuestion(currentQuestionNum);
                } else {
                    Intent intent = new Intent("com.comp3617.assignment1.quizapp.ScoreActivity");
                    double score = Math.round ( (double)calculateTotalScore() / totalNumOfQuestions * 100);
                    intent.putExtra("score", score + " / 100");
                    startActivity(intent);
                }
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        currentQuestionNum = 1;
        showQuestion(currentQuestionNum);
    }

    private void showQuestion(int number) {
        int questionId = getResources().getIdentifier("q" + number, "string", getApplicationContext().getPackageName());
        int option1Id = getResources().getIdentifier("opt" + number + "_1", "string", getApplicationContext().getPackageName());
        int option2Id = getResources().getIdentifier("opt" + number + "_2", "string", getApplicationContext().getPackageName());
        int option3Id = getResources().getIdentifier("opt" + number + "_3", "string", getApplication().getPackageName());
        int option4Id = getResources().getIdentifier("opt" + number + "_4", "string", getApplicationContext().getPackageName());
        int answerId = getResources().getIdentifier("answer" + number, "string", getApplicationContext().getPackageName());
        tvQuestion.setText(getResources().getText(questionId));
        radioButton1.setText(getResources().getText(option1Id));
        radioButton2.setText(getResources().getText(option2Id));
        radioButton3.setText(getResources().getText(option3Id));
        radioButton4.setText(getResources().getText(option4Id));
        answer = getResources().getText(answerId).toString();

        radioButton1.setChecked(false);
        radioButton2.setChecked(false);
        radioButton3.setChecked(false);
        radioButton4.setChecked(false);
    }

    private void resetScoresheet() {
        for(int i = 0; i < scoresheet.length; i++) {
            scoresheet[i] = 0;
        }
    }

    private int calculateTotalScore() {
        int result = 0;
        for(int i = 0; i < scoresheet.length; i++) {
            result += scoresheet[i];
        }
        return result;
    }

    private boolean isRadioButtonChecked() {
        return radioButton1.isChecked() || radioButton2.isChecked() || radioButton3.isChecked() || radioButton4.isChecked();
    }
}
