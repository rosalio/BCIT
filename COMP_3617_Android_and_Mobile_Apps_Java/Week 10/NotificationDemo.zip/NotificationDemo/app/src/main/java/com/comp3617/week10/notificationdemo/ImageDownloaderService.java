package com.comp3617.week10.notificationdemo;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;


/**
 * An {@link IntentService} subclass for handling asynchronous task requests in
 * a service on a separate handler thread.
 * <p/>
 * TODO: Customize class - update intent actions and extra parameters.
 */
public class ImageDownloaderService extends IntentService {

    public ImageDownloaderService() {
        super("ImageDownloaderService");
    }

    private static final  int NOTIFICATION_ID = 100;

    @Override
    protected void onHandleIntent(Intent intent) {

        String url = intent.getStringExtra(MainActivity.DOWNLOAD_IMG_URL);
                //getExtras().getString(MainActivity.DOWNLOAD_IMG_URL);

        HttpURLConnection conn = null;
        int p = 0;
        try {
            final URL imgURL = new URL(url);
            conn  = (HttpURLConnection)imgURL.openConnection();

            InputStream is = new BufferedInputStream(conn.getInputStream());
            String outputFile = getFileLocation();
            OutputStream os = new FileOutputStream(outputFile);

            while((p = is.read()) != -1)
                os.write(p);
            os.close();
            is.close();
            //Done download the file
            showNotification(outputFile);
        }
        catch (Exception e) {
            e.printStackTrace();
            //handle the exception
        }

    }
    private void showNotification(String downloadedLocation) {
        NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);

        Notification.Builder builder = new Notification.Builder(this);
        builder.setContentTitle("Image Downloader");
        builder.setContentText("Finished downloading...");
        builder.setSmallIcon(R.mipmap.ic_launcher);
        builder.setAutoCancel(true);

        Intent intent = new Intent(this, DisplayImageActivity.class);
        intent.setAction(MainActivity.SHOW_IMG_ACTION);
        intent.putExtra(MainActivity.DOWNLOAD_IMG_LOC, downloadedLocation);

        PendingIntent pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(pi);


        manager.notify(NOTIFICATION_ID, builder.build());
    }

    private String getFileLocation(){
        int random = new Random().nextInt();
        String downloadLoc = getCacheDir() + File.pathSeparator + String.format("%d.jpg", random);
        return downloadLoc;
    }


}
