package com.comp3617.week10.notificationdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    public static final String DOWNLOAD_IMG_URL = "IMG_URL";
    public static final String DOWNLOAD_IMG_LOC = "IMG_LOC";
    public static final String SHOW_IMG_ACTION = "SHOW_IMG";

    public static final String IMG_URL = "http://mcescher.com/wp-content/uploads/2013/10/LW355-MC-Escher-Drawing-Hands-1948.jpg";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View v){
        Intent i = new Intent(this, ImageDownloaderService.class);
        i.putExtra(DOWNLOAD_IMG_URL, IMG_URL);

        startService(i);
    }
}
