package com.comp3617.week10.notificationdemo;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

public class DisplayImageActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_image);

        Intent i = getIntent();
        if (i != null) { //Also make sure the action name matches
            String downloadedLocation = i.getStringExtra(MainActivity.DOWNLOAD_IMG_LOC);
            if (downloadedLocation != null) {
                //We got the image location
                Bitmap bmp = BitmapFactory.decodeFile(downloadedLocation);
                ImageView iv = (ImageView)findViewById(R.id.imageView);
                iv.setImageBitmap(bmp);
            }
        }

    }
}
