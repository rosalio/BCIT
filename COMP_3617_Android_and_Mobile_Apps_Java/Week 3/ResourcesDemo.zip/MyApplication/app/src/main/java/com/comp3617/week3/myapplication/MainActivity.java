package com.comp3617.week3.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btnOK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Getting a reference to a string defined in string.xml file
        //getString(R.string.app_name)

        btnOK = (Button)findViewById(R.id.btnOk);
    }
}
