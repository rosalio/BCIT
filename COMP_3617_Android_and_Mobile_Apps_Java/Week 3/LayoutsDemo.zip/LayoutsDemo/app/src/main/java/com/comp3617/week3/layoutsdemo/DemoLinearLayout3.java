package com.comp3617.week3.layoutsdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DemoLinearLayout3 extends AppCompatActivity {

    private EditText etMessage;
    private Button btnSend;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo_linear_layout3);


        //Get a reference to the views
        etMessage = (EditText) findViewById(R.id.etMessage);
        btnSend = (Button) findViewById(R.id.btnSend);

       //Set up an event handler for the button
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg = etMessage.getText().toString();
                Toast.makeText(DemoLinearLayout3.this, msg, Toast.LENGTH_LONG).show();
            }
        });
    }
}
