package com.comp3617.week8.threadingdemo;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

     TextView tvNumber;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvNumber = (TextView)findViewById(R.id.tvNumber);
    }

    public void onClick(View v) {
        EditText etNumber = (EditText)findViewById(R.id.etNumber);

        String number = etNumber.getText().toString();
        final int n = Integer.parseInt(number);

        if (v.getId() == R.id.btnThread) {
          new Thread(new Runnable() {
                public void run() {
                    //Performing the long running op on the worker thread
                    final long f =  fib(n);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //Updating user interface on the UI thread
                            tvNumber.setText(Long.toString(f));
                        }
                    });
                }
            }).start();

        }
        else if (v.getId() == R.id.btnAsync) {
            new ComputeFibAsyncTask().execute(n);
        }
    }


    private class ComputeFibAsyncTask extends AsyncTask<Integer, String, String> {

        @Override
        protected String doInBackground(Integer... params) {
           int N = params[0];
           long f = 0L;
           for (int i = 1; i <= N; i++) {
                f = fib(i);
                //Update progress for each Fibonacci number
                String msg = String.format("Fib (%d) = %d", i, f);
                publishProgress(msg);
            }

            return String.format("Fib (%d) = %d", N, f);
        }

        @Override
        protected void onProgressUpdate(String... values) {
           //Update a text View here with progress
            tvNumber.setText(values[0]);
        }

        @Override
        protected void onPostExecute(String s) {
            //Update a text View here with final value
            tvNumber.setText(s);
        }
    }


    private static long fib(int n){
        if(n <= 1)
            return n;
        else
            return fib(n - 1) + fib(n - 2);
    }
}
