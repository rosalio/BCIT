package com.comp3617.week8.networkingdemo;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private static final String GOOGLE_API = "http://ajax.googleapis.com/ajax/services/search/web?v=1.0&q=";
    private EditText etSearch;
    private TextView tvSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etSearch = (EditText)findViewById(R.id.etSearch);
        tvSearch = (TextView)findViewById(R.id.tvSearch);
    }


    public void onClick(View v){
        //Launch the search operation
        String query = etSearch.getText().toString();
        query = GOOGLE_API + query;

        Log.d("Networking Demo", "onClick() called");
        new SearchTask().execute(query);

    }


    private class SearchTask extends AsyncTask<String, Void, String> {

        private Exception exception = null;
        @Override
        protected String doInBackground(String... params) {
            String urlString = params[0];

            StringBuilder response = new StringBuilder();

            try {
                URL url = new URL(urlString);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader rdr = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String line = null;
                    while ((line = rdr.readLine()) != null) {
                        response.append(line);
                    }
                    rdr.close();
                }
                else
                    return "Oops something went wrong";
            }
            catch (Exception e) {
                exception = e;
            }
            return parseJSONResponse(response.toString());
        }


        @Override
        protected void onPostExecute(String s) {
            if (exception == null) {
                tvSearch.setText(s);
            }
            else
                tvSearch.setText("Exception : " + exception.getMessage());
        }

        private String parseJSONResponse(String response) {
            StringBuilder ret = new StringBuilder();

            try {
                JSONObject json = new JSONObject(response);
                JSONObject responseData = json.getJSONObject("responseData");
                JSONArray results = responseData.getJSONArray("results");
                for(int i = 0 ; i < results.length(); i++) {
                    String title = results.getJSONObject(i).getString("title");
                    ret.append(title); ret.append("\t");
                }

            }catch (JSONException e) {
                exception = e ;
            }

            return ret.toString();
        }
    }


}
