package com.comp3617.week6.staticfragmentsdemo;

import android.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements NHLTeamsFragment.TeamChangeListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onSelectedTeamListener(int index) {
      //Lookup for the Team Fragment
        FragmentManager fragmentManager = getFragmentManager();
        NHLTeamFragment nhlTeamFragment = (NHLTeamFragment)fragmentManager.findFragmentById(R.id.teamFragment);
        if (nhlTeamFragment != null) {
            nhlTeamFragment.setTeam(index);
        }

    }
}
