package com.comp3617.week6.staticfragmentsdemo;


import android.app.Activity;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


/**
 * A simple {@link Fragment} subclass.
 */
public class NHLTeamsFragment extends Fragment implements View.OnClickListener {


    public interface TeamChangeListener {
        void onSelectedTeamListener(int index);
    }
    

    public NHLTeamsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.nhl_teams, container, false);
        v.findViewById(R.id.rbCanucks).setOnClickListener(this);
        v.findViewById(R.id.rbFlames).setOnClickListener(this);
        v.findViewById(R.id.rbOilers).setOnClickListener(this);
        v.findViewById(R.id.rbToronto).setOnClickListener(this);


        return v;
    }

    @Override
    public void onClick(View v) {
     Activity parentActivity = getActivity();

        try {
            TeamChangeListener listener = (TeamChangeListener)parentActivity;
            listener.onSelectedTeamListener(radioButtonToIndex(v.getId()));
        }
        catch (ClassCastException ce) {
            throw ce;
        }
    }

    private int radioButtonToIndex(int id) {
        if (id == R.id.rbCanucks)
            return 0;
        else if (id == R.id.rbFlames)
            return 1;
        else if (id == R.id.rbOilers)
            return 2;
        else if (id == R.id.rbToronto)
            return 3;
        else
            return -1;
    }
}
