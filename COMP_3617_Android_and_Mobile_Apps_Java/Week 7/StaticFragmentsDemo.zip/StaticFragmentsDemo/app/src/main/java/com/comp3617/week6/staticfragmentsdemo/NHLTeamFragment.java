package com.comp3617.week6.staticfragmentsdemo;


import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class NHLTeamFragment extends Fragment {


    final String SELECTED_TEAM_KEY = "SELECTED_TEAM";
    private TextView team;
    private ImageView logo;



    private int index = 0;

    private int[] logo_ids = { R.drawable.cannhl, R.drawable.flamesnhl, R.drawable.oilersnhl,
            R.drawable.torontonhl
    };

    private String[] teams;


    public NHLTeamFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.nhl_team, container, false);
        team = (TextView)v.findViewById(R.id.tvTeamName);
        logo = (ImageView)v.findViewById(R.id.ivLogo);
        teams = getResources().getStringArray(R.array.nhlTeams);

        //Get the last saved index from the savedInstance bundle
        if (savedInstanceState != null) {
            index = savedInstanceState.getInt(SELECTED_TEAM_KEY, 0);
        }

        setTeam(index);

        return v;
    }

    public void setTeam(int index){
        this.index = index;
        team.setText(teams[index]);
        logo.setImageResource(logo_ids[index]);
    }


    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(SELECTED_TEAM_KEY, index);
    }
}
