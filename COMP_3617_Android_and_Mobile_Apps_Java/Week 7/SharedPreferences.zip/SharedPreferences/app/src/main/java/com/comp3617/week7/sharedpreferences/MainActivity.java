package com.comp3617.week7.sharedpreferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View v) {
        if (v.getId() == R.id.btnDisplay) {
            SharedPreferences prefs = getPreferences(Context.MODE_PRIVATE);
            Toast.makeText(this, prefs.getString("Message", "Not found"), Toast.LENGTH_LONG).show();
        }
        else if (v.getId() == R.id.btnSave){
            SharedPreferences prefs = getPreferences(Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("Message", "Hello world");
            editor.commit();
        }
    }
}
