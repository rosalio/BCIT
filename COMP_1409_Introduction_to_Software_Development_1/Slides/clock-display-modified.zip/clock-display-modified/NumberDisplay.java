
/**
 * The NumberDisplay class represents a digital number display that can hold
 * values from zero to a given limit. The limit can be specified when creating
 * the display. The values range from zero (inclusive) to limit-1. If used,
 * for example, for the seconds on a digital clock, the limit would be 60, 
 * resulting in display values from 0 to 59. When incremented, the display 
 * automatically rolls over to zero when reaching the limit.
 * 
 * @author Michael Kölling and David J. Barnes
 * @author modified by Colleen Penrowley 
 * @version 2011.07.31
 * @version 2012.10.23
 */
public class NumberDisplay
{
    public static final int INITIAL_LIMIT = 1;
    public static final int INITIAL_VALUE = 0;
    public static final int TWO_DIGIT_NUMBER = 10;
    public static final String LEADING_ZERO = "0";
    public static final String EMPTY_STRING = "";
    
    private int limit;
    private int value;

     /**
     * Default constructor for NumberDisplay
     */
    public NumberDisplay()
    {
        setLimit(INITIAL_LIMIT);
        setValue(INITIAL_VALUE);
    }
 
    /**
     * Constructor for objects of class NumberDisplay.
     * Set the limit at which the display rolls over.
     * @param rollOverLimit one past the maximum number
     */
    public NumberDisplay(int rollOverLimit)
    {
        setLimit(rollOverLimit);
        setValue(INITIAL_VALUE);
    }

    /**
     * Set the roll-over limit - Limit must be greater than zero.
     * @param limitToSet the rollover limit for this NumberDisplay
     */
    final public void setLimit(int limitToSet)
    {
        if (limitToSet > 0) {
            limit = limitToSet;
        }
        else {
            limit = INITIAL_LIMIT;
        }
    }
    
    /**
     * Return the current value.
     * @return current value
     */
    public int getValue()
    {
        return value;
    }

    /**
     * Return the display value (that is, the current value as a two-digit
     * String. If the value is less than ten, it will be padded with a leading
     * zero).
     * @return current value as String
     */
    public String getDisplayValue()
    {
        if(value < TWO_DIGIT_NUMBER) {
            return LEADING_ZERO + value;
        }
        else {
            return EMPTY_STRING + value;
        }
    }

    /**
     * Set the value of the display to the new specified value. If the new
     * value is less than zero or over the limit, do nothing.
     * @param replacementValue new value
     */
    public void setValue(int replacementValue)
    {
        if((replacementValue >= 0) && (replacementValue < limit)) {
            value = replacementValue;
        }
    }

    /**
     * Increment the display value by one, rolling over to zero if the
     * limit is reached.
     */
    public void increment()
    {
        value = (value + 1) % limit;
    }
}
