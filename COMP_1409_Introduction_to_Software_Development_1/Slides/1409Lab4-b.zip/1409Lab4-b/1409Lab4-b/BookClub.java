
/**
 * Write a description of class BookClub here.
 * 
 * @author (Rana Alsammarraie) 
 * @version (2014-02-2)
 */
public class BookClub
{
    public static final int BUYING_ONE_BOOK = 1;
    public static final int BUYING_TWO_BOOKS = 2;
    public static final int BUYING_THREE_BOOKS = 3;
    public static final int BUYING_FOUR_BOOKS = 4;

    public static final int POINTS_OF_BUYING_ONE_BOOK = 5;
    public static final int POINTS_OF_BUYING_tWO_BOOKS = 15;
    public static final int POINTS_OF_BUYING_THREE_BOOKS = 30; 
    public static final int POINTS_OF_BUYING_FOUR_BOOKS = 60;
    public static final int BONUS_POINTS_OF_BUYING_TEN_BOOKS = 20;
    public static final int NUMBER_TO_EARN_BONUS = 10;

    private static int totalBooksPurchased = 0;
    
    private String clientName;
    private int numberOfPurchasedBooksPerMonth;
    private double bookPriceInCAD;

  
    /**
     * BookClub  default Constructor
     *
     */
    public BookClub(){
        clientName = "";
        numberOfPurchasedBooksPerMonth = 0;
        bookPriceInCAD = 0;
    }

    /**
     * BookClub Constructor
     *
     * @param name A parameter to set ClientName
     * @param numberOfBooks A parameter to set numberOfPurchasedBooksPerMonth
     * @param priceInCAD A parameter to set bookPriceInCAD
     */
    public BookClub(String name, int numberOfBooks,double priceInCAD){
        if(name == null){
            clientName = "";
        }
        else{
            clientName = name; 
        }

        if(numberOfBooks >0){
            numberOfPurchasedBooksPerMonth = numberOfBooks;
            totalBooksPurchased = totalBooksPurchased + numberOfBooks;
        }
        else{
            numberOfPurchasedBooksPerMonth = 0; 
        }

        if(priceInCAD > 0){
            bookPriceInCAD = priceInCAD;
        }
        else{
            bookPriceInCAD = 0;
        }  
    }

    /**
     * Method getClientName
     *
     * @return The return clientName
     */
    public String getClientName(){
        return clientName;
    }

    /**
     * Method getNumberOfPurchasedBooksPerMonth
     *
     * @return The return numberOfPurchasedBooksPerMonth
     */
    public int getNumberOfPurchasedBooksPerMonth(){
        return numberOfPurchasedBooksPerMonth;
    }

    /**
     * Method getBookPriceInCAD
     *
     * @return The return bookPriceInCAD
     */
    public double getBookPriceInCAD(){
        return bookPriceInCAD;
    }

    /**
     * Method getTotalNumberOfPurchasedBooks
     *
     * @return The return totalNumberOfPurchasedBooks
     */
    public static int getBooksPurchasedByAllCustomers(){
        return totalBooksPurchased;
    }

    /**
     * Method setClientName
     *
     * @param name A parameter to set ClientName
     */
    public void setClientName(String name){
        if(name != null){
            clientName = name;
        }

    }

    /**
     * Method setNumberOfPurchasedBooksPerMonth
     *
     * @param newNumberOfBooks A parameter to increase numberOfPurchasedBooksPerMonth
     */
    public void setNumberOfPurchasedBooksPerMonth( int newNumberOfBooks){
        if(newNumberOfBooks > 0){
            numberOfPurchasedBooksPerMonth = numberOfPurchasedBooksPerMonth + newNumberOfBooks;
            totalBooksPurchased = totalBooksPurchased + newNumberOfBooks;
        }
    }

    /**
     * Method setBookPriceInCAD
     *
     * @param priceInCAD A parameter  to set bookPriceInCAD
     */
    public void setBookPriceInCAD(double priceInCAD){
        if(priceInCAD > 0){ 
            bookPriceInCAD = priceInCAD;
        }
    }

    /**
     * Method calculateBookPoints to calculate the total points
     * earned form buying books 
     *
     * @return The return totalPoints
     */
    public int calculateBookPoints()
    {
        int totalPoints = 0;
        if(numberOfPurchasedBooksPerMonth == BUYING_ONE_BOOK){
            totalPoints = totalPoints + POINTS_OF_BUYING_ONE_BOOK;
        }
        else if(numberOfPurchasedBooksPerMonth == BUYING_TWO_BOOKS){
            totalPoints = totalPoints + POINTS_OF_BUYING_tWO_BOOKS;
        }
        else if(numberOfPurchasedBooksPerMonth == BUYING_THREE_BOOKS){
            totalPoints = totalPoints + POINTS_OF_BUYING_THREE_BOOKS;
        }
        else{
            totalPoints = totalPoints + POINTS_OF_BUYING_FOUR_BOOKS;
        }

        if(totalBooksPurchased >= NUMBER_TO_EARN_BONUS){
            totalPoints = totalPoints + BONUS_POINTS_OF_BUYING_TEN_BOOKS;
        }
        return totalPoints;
    }
}

   
