
/**
 * Cat - yet another 1409 demo.
 * 
 * @author Colleem 
 * @version 2013.10.15
 */
public class Cat
{
    private String name;
    private int ageInYears;
    private double weightInKg;

    /**
     * Constructor for objects of class Cat
     */
    public Cat()
    {
        setName("");
        setAgeInYears(0);
        setWeightInKg(0.0);
    }

    /**
     * Cat constructor.
     * @param theName cat's name
     * @param theAgeInYears cat's age in years
     * @param theWeightInKg cat's weight in kilograms
     */
    public Cat (String theName, int theAgeInYears, double theWeightInKg)
    {
       setName(theName);
       setAgeInYears(theAgeInYears);
       setWeightInKg(theWeightInKg);
    }
    
    /**
     * @param theName cat's new name
     */
    public void setName(String theName)
    {
        if(theName != null){
            name = theName;
        }
        else if(name == null) {
            name = "";
        }
    }
    
    /**
     * @param theAgeInYears cat's new age
     */
    public void setAgeInYears(int theAgeInYears)
    {
        if(theAgeInYears > 0){
            ageInYears = theAgeInYears;
        }
    }
    
    /**
     * @param theWeightInKg cat's new weight in kilograms
     */
    public void setWeightInKg(double theWeightInKg)
    {
        if(theWeightInKg > 0.0) {
            weightInKg = theWeightInKg;
        }
    }
    
    /**
     * @return name
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * @return age in years
     */
    public int getAgeInYears()
    {
        return ageInYears;
    }
    
    /**
     * @return weight in kilos
     */
    public double getWeightInKg()
    {
        return weightInKg;
    }
    
    /**
     * Displays cat details.
     */
    public void displayDetails()
    {
        System.out.println(getName() + " is " + getAgeInYears() + 
            " years old and weighs " + getWeightInKg() + " kilos.");
    }
}
