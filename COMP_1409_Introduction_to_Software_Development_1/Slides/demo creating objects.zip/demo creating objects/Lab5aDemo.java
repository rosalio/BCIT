
/**
 * Lab5aDemo - practice creating objects in code
 * 
 * @author Colleen 
 * @version 2013.10.15
 */
public class Lab5aDemo
{
    public static void demo()
    {
        String name = "";
        int age = 0;
        double weightInKg = 0.0;
        InputReader reader = new InputReader();
        System.out.print("Please type cat's name: ");
        name = reader.readString();
        System.out.print("Cat's age in years: ");
        age = reader.readInt();
        System.out.print("Cat's weight in kilos: ");
        weightInKg = reader.readDouble();
        
        Cat theCat = new Cat(name, age, weightInKg);
        theCat.displayDetails();
        
    }
}









