
/**
 * CarRace - where drivers go to speed.
 * 
 * @author Colleen 
 * @version 2014.02.09
 */
public class CarRace
{
    private Driver driver1;
    private Driver driver2;

    /**
     * Default constructor
     */
    public CarRace()
    {
        setDriver1(new Driver());
        setDriver2(new Driver());

    }

    /**
     * Constructor
     */
    public CarRace(Driver d1, Driver d2 )
    {
        setDriver1(d1);
        setDriver2(d2);
    }

    /**
     * Sets driver1 field
     * @param newDriver1
     */
    public void setDriver1(Driver d1)
    {
        if(d1 != null){
            driver1 = d1;
        }
        else {
            driver1 = new Driver();
        }
    }
    
    /**
     * Sets driver2 field
     */
    public void setDriver2(Driver d2)
    {
        if(d2 != null){
            driver2 = d2;
        }
        else {
            driver2 = new Driver();
        }    
    }
    
    /**
     * Gets driver1
     * @return driver1
     */
    public Driver getDriver1()
    {
        return driver1;
    }
    
    /**
     * Gets drive2
     * @return driver2
     */
    public Driver getDriver2()
    {
        return driver2;
    }

     /**
     * Locate and return the fastest driver.
     * @return driver with fastest speed
     */
    public Driver getFastestDriver()
    {
        int driver1Speed = driver1.getSpeedInKPerHour();
        int driver2Speed = driver2.getSpeedInKPerHour();
        if(driver1Speed > driver2Speed){
            return driver1;
        }
        else {
            return driver2;
        }
    }
    
    /**
     * Show contenders.
     */
    public void showContenders()
    {
        driver1.displayDetails();
        driver2.displayDetails();
    }
    

}
