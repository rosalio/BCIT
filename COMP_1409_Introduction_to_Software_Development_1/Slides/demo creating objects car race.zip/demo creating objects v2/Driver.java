
/**
 * Write a description of class Driver here.
 * 
 * @author (Rana Alsammarraie) 
 * @version (2014/01/25)
 */
public class Driver
{

    private String name;
    private String driverLicense;
    private int speedInKPerHour;
    private String driverStanding;

	
    /**
     * Driver  default Constructor
     *
     */
    public Driver(){
        name = "";
        driverLicense = "";
        speedInKPerHour = 0;
        driverStanding = "";
    }

    
    
    /**
     * Driver Constructor
     *
     * @param newName to set the name
     * @param newDriverLicense to set the driverLicense
     * @param newSpeedInKPerHour to set the speedInKPerHour
     */
    public Driver(String newName, String newDriverLicense, int newSpeedInKPerHour) {

        name = newName;
        driverLicense = newDriverLicense;
        if(newSpeedInKPerHour > 0){
            speedInKPerHour = newSpeedInKPerHour;
        }
        else{
            speedInKPerHour = 0;
        }
        driverStanding = "";
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param newName to set the name 
     */
    public void setName(String newName) {
        name = newName;
    }

    /**
     * @return the driverLicense
     */
    public String getDriverLicense() {
        return driverLicense;
    }

    /**
     * @param newDriverLicense to set the driverLicense 
     */
    public void setDriverLicense(String newDriverLicense) {
        driverLicense = newDriverLicense;
    }

    /**
     * @return the speedInKPerHour
     */
    public int getSpeedInKPerHour() {
        return speedInKPerHour;
    }

    /**
     * @param newSpeedInKPerHour to set  the speedInKPerHour 
     */
    public void setSpeedInKPerHour(int newSpeedInKPerHour) {
        if(newSpeedInKPerHour > 0){
            speedInKPerHour = newSpeedInKPerHour;
        }
    }

    /**
     * @return the driverStanding
     */
    public String getDriverStanding() {
        return driverStanding;
    }

    /**
     * @param newDriverStanding to set the driverStanding 
     */
    public void setDriverStanding() {
        if(speedInKPerHour <= 60){
            driverStanding = "no ticket";
        }
        else if(speedInKPerHour <= 80){
            driverStanding = "small ticket";
        }
        else{
            driverStanding = "big ticket";
        }
        
    }

    /**
     * Method displayDetails to display the details of the driver
     *
     */
    public void displayDetails(){

        System.out.println(" Driver name : " + name);
        System.out.println("Driver License number : " +driverLicense );
        System.out.println("Speed : " + speedInKPerHour);
       // System.out.println("Driver Standing : " + driverStanding );
    }

}
