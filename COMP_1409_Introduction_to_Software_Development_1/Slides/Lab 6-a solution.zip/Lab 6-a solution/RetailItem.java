
/**
 * Write a description of class RetailItem here.
 * 
 * @author (Rana Alsammarraie) 
 * @version (2014-01-20)
 */
public class RetailItem
{
    
    private String itemDescription;
    private double itemPriceInCAD;
    private boolean isOnDemand;
    private int numberOfUnitsInStock;

    /**
     * RetailItem defaul Constructor
     *
     */
    public RetailItem(){
        itemDescription = "";
        itemPriceInCAD = 0.0;
        isOnDemand = false;
        numberOfUnitsInStock = 0;
    }

    /**
     * RetailItem Constructor
     *
     * @param newItemDescription A parameter
     * @param newItemPriceInCAD A parameter
     * @param newIsOnDemand A parameter
     * @param newNumberOfUnitsInStock A parameter
     */
    public RetailItem(String newItemDescription, double newItemPriceInCAD,
                      boolean newIsOnDemand, int newNumberOfUnitsInStock) {
        itemDescription = newItemDescription;
        itemPriceInCAD = newItemPriceInCAD;
        isOnDemand = newIsOnDemand;
        numberOfUnitsInStock = newNumberOfUnitsInStock;
    }

    /**
     * @return the itemDescription
     */
    public String getItemDescription() {
        return itemDescription;
    }

    /**
     * @return the itemPriceInCAD
     */
    public double getItemPriceInCAD() {
        return itemPriceInCAD;
    }

    /**
     * @return the isOnDemand
     */
    public boolean isOnDemand() {
        return isOnDemand;
    }

    /**
     * @return the numberOfUnitsInStock
     */
    public int getNumberOfUnitsInStock() {
        return numberOfUnitsInStock;
    }

}
