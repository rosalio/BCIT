
/**
 * Demonstration of the uses of "static"
 * 
 * @author Colleen
 * @version Feb 09
 */
public class DemoStatic
{
    private static int count = 0;
    private int test;
       
    /** 
     * Constructor increments static variable for each object created
     */
    public DemoStatic() 
    {
        count = count + 1;
        test = 0;
    }
    
    /**
     * Static method 
     */
    public static int getCount()
    {
       return count;
       //return test;
    }
    
    /**
     * Gets object count from static variable.
     * @return object count
     */
    public int getObjectCount()
    {
        return count;
    }

}
