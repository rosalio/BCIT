
/**
 * Write a description of class Student here.
 * 
 * @author (Rana Alsammarraie) 
 * @version (2014/01/26)
 */

public class Student
{
    public static final int MIN_GRADE = 0;
    public static final int MAX_GRADE = 100;
    public static final int DISCOUNTED_VALUE = 700;
    public static final double DISCOUNT_RATE = 0.85;
    
    private String studentName;
    private String studentID;
    private int testGrade;
    private double courseFeesInCAD;
    private boolean isEligibleForDiscount;

    /**
     * Student default Constructor
     *
     */
    public Student(){
        studentName = "";
        studentID = "";
        testGrade = MIN_GRADE;
        courseFeesInCAD = 0.0;
        isEligibleForDiscount = false;
    }
    
    /**
     * Student Constructor
     *
     * @param newStudentName  to set the studentName
     * @param newStudentID  to set the studentID
     * @param newTestGrade  to set the testGrade
     * @param newCourseFeesInCAD  to set the testGrade
     */
    public Student(String newStudentName, String newStudentID, 
                   int newTestGrade,double newCourseFeesInCAD)
    {

        if(newStudentName != null){
            studentName = newStudentName;
        }
        else {
            studentName = "";
        }
        if(newStudentID != null){
            studentID = newStudentID;
        }
        else{
            studentID = "";
        }
        isEligibleForDiscount = false;
        
        if(newTestGrade >= MIN_GRADE && newTestGrade <= MAX_GRADE){
            testGrade = newTestGrade;
        }
        else{
            testGrade = MIN_GRADE;
        }
        if(newCourseFeesInCAD > 0.0){
            courseFeesInCAD = newCourseFeesInCAD;
        }
        else{
            courseFeesInCAD = 0.0;
        }
    }

    /**
     * @return the studentName
     */
    public String getStudentName() {
        return studentName;
    }

    /**
     * @return the studentID
     */
    public String getStudentID() {
        return studentID;
    }

    /**
     * @return the testGrade
     */
    public int getTestGrade() {
        return testGrade;
    }

    /**
     * @return the courseFeesInCAD
     */
    public double getCourseFeesInCAD() {
        return courseFeesInCAD;
    }

    /**
     * @return the isEligibleForDiscount
     */
    public boolean isEligibleForDiscount() {
        return isEligibleForDiscount;
    }

    /**
     * @param newStudentName  to set the studentName 
     */
    public void setStudentName(String newStudentName) {
        if(newStudentName != null){
            studentName = newStudentName;
        }
    }

    /**
     * @param newStudentID to set the the studentID 
     */
    public void setStudentID(String newStudentID) {
        if(newStudentID != null) {
            studentID = newStudentID;
        }
    }

    /**
     * @param newTestGrade to set the testGrade 
     */
    public void setTestGrade(int newTestGrade) {
        if(newTestGrade >= MIN_GRADE && newTestGrade <= MAX_GRADE){
            testGrade = newTestGrade;
        }
    }

    /**
     * @param newCourseFeesInCAD to set the courseFeesInCAD 
     */
    public void setCourseFeesInCAD(double newCourseFeesInCAD) {
        if(newCourseFeesInCAD > 0){
            courseFeesInCAD = newCourseFeesInCAD;
        }
    }

    /**
     * @param newIsEligibleForDiscount to set the isEligibleForDiscount 
     */
    public void setEligibleForDiscount(boolean newIsEligibleForDiscount) {
        isEligibleForDiscount = newIsEligibleForDiscount;
    }

    /**
     * Method checkForDiscount to check the course fees and sets 
     * isEligibleForAdiscount field accordingly
     *
     */
    public void checkForDiscount(){
        if(courseFeesInCAD > DISCOUNTED_VALUE){
            courseFeesInCAD = courseFeesInCAD * DISCOUNT_RATE;
            isEligibleForDiscount = true;
        }
        else{
            isEligibleForDiscount = false;
            System.out.println("The student is not eligible for a discount ");
        }
    }

    /**
     * Method displayDetails to display the details of the student
     *
     */
    public void displayDetails(){
        System.out.println("Student Name : " + studentName);
        System.out.println("Student ID : "+ studentID);
        System.out.println("Test Score : " + testGrade);
        if(isEligibleForDiscount == true){
        //if(isEligibleForDiscount){    
            System.out.println(" The student gets a discount of 15%");
        }
        else{
            System.out.println(" The student is not eligible for a discount ");
        }
        System.out.println("the course fees : " + courseFeesInCAD);
        System.out.println();
    }

}
