
/**
 * Write a description of class Employee here.
 * 
 * @author (Rana Alsmmarraie) 
 * @version (2014-01-20)
 */
public class Employee
{
    private String employeeName;
    private int employeeAgeInYears;
    private String employeeAddress;
    private int numberofYearsEmployed;
    private double annualPayInCAD;
    private boolean isFullTime;

    /**
     * Employee default Constructor
     *
     */
    public Employee(){
        employeeName = "";
        employeeAgeInYears = 0;
        employeeAddress = "";
        numberofYearsEmployed = 0;
        annualPayInCAD = 0.0;
        isFullTime = false;
    }

    
    /**
     * Employee Constructor
     *
     * @param newName A parameter
     * @param newAddress A parameter
     * @param newAgeInYears A parameter
     * @param newNumberOfYearsEmployed A parameter
     * @param newAnnualPay A parameter
     * @param newIsFullTime A parameter
     */
    public Employee(String newEmployeeName, String newAddress,int newAgeInYears,
    int newNumberOfYearsEmployed, double newAnnualPay, boolean newIsFullTime){
        employeeName = newEmployeeName;
        employeeAgeInYears = newAgeInYears;
        employeeAddress = newAddress;
        numberofYearsEmployed = newNumberOfYearsEmployed;
        annualPayInCAD = newAnnualPay;
        isFullTime = newIsFullTime;
    }

    /**
     * Method getemployeeName
     *
     * @return The employeeName value
     */
    public String getEmployeeName(){
        return employeeName;
    }

    /**
     * Method getEmployeeAddress
     *
     * @return The employeeAddress value
     */
    public String getEmployeeAddress(){
        return employeeAddress;
    }

    /**
     * Method getemployeeAgeInYears
     *
     * @return The employeeAgeInYears value
     */
    public int getemployeeAgeInYears(){
        return employeeAgeInYears;
    }

    /**
     * Method getNumberofYearsEmployed
     *
     * @return The numberofYearsEmployed value
     */
    public int getNumberofYearsEmployed(){
        return numberofYearsEmployed;
    }

    /**
     * Method getAnnualPayInCAD
     *
     * @return The return value
     */
    public double getAnnualPayInCAD(){
        return annualPayInCAD;
    }

    /**
     * Method getIsFullTime
     *
     * @return The return value
     */
    public boolean getIsFullTime(){
        return isFullTime;
    }

}
