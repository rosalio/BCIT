import java.util.ArrayList;
import java.util.Iterator;

/**
 * Agency - to demo ArrayList
 * 
 * @author Colleen 
 * @version 2013.02.28
 */
public class Agency
{
    private ArrayList<Model> models;

    /**
     * Constructor for objects of class Agency
     */
    public Agency()
    {
        models = new ArrayList<Model>();
    }

    /**
     * Adds a model to the agency
     * @param aModel to add
     */
    public void addModel(Model aModel)
    {
        models.add(aModel);
    }

    /**
     * Shows last names of models
     */
    public void showNames()
    {
        for(Model oneModel : models){
            System.out.println(oneModel.getLastName());        
        }
    }

    /**
     * Calculates the average height of the models.
     * @return average model height
     */
    public double calculateAverageHeightInches()
    {
        int index = 0;
        int sumOfHeights = 0;
        double average = 0.0;
        while(index < models.size()){
            sumOfHeights += models.get(index).getHeightInInches();
            index++;
        }
        if(models.size() > 0){
            average = sumOfHeights/ models.size();
        }
        return average;
    }
    
    /**
     * Removes all smokers from the collection.
     */
    public void fireSmokers()
    {
        Iterator<Model> it = models.iterator();
        while(it.hasNext()){
            Model aModel = it.next();
            if(aModel.getSmokes()){
                it.remove();
            }
        }
    }

}














