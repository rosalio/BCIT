
/**
 * Student class - a very simple model of a student.
 * To demonstrate decisions and logic for comp 1409 session 3.
 * 
 * @author Colleen Penrowley 
 * @version Spring 2006
 */
public class Student
{
    // instance variables 
    private String firstName;
    private String lastName;
    private double grade;

    /**
     * Default constructor
     */
    public Student()
    {
        firstName = "";
        lastName = "";
        grade = 0.0;
    }
    
    /**
     * Constructor for objects of class Student
     * 
     * @param firstName  the student's first name
     * @param lastName  the student's last name
     */
    public Student(String sFirstName, String sLastName)
    {
        firstName = sFirstName;
        lastName = sLastName;
        grade = 0.0;
    }

    /**
     * Changes the student's grade.
     * This method tests to ensure the parameter is a valid
     * grade, i.e. between 0.0 and 100.0. If the grade is not
     * valid it is not set, and an error message is displayed.
     * 
     * @param  double new grade
     */
    public void setGrade(double newGrade)
    {
        if(newGrade < 0.0){
            System.out.println("too low!");
        }
        else {
            if(newGrade > 100.0){
                System.out.println("too high!");
            }
            else {
                grade = newGrade;
            }
        }
    }
    
    /**
     * Returns the student's grade.
     * 
     * @return the student's grade as a double
     */
    public double getGrade()
    {
        return grade;
    }
    
    /**
     * Returns the student's full name, i.e. first name and last name
     * 
     * @return the student's full name as a String
     */
    public String getFullName()
    {
        return firstName + " " + lastName;
    }
}
