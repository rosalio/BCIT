
/**
 * Write a description of class CommissionSales here.
 * 
 * @author (Rana Alsammarraie) 
 * @version (2014-02-09)
 */
public class CommissionSales
{
    public static final double RATE_A = 0.05;
    public static final double RATE_B = 0.10;
    public static final double RATE_C = 0.12;
    public static final double RATE_D = 0.14;
    public static final double RATE_E = 0.16;

    public static final int RATE_A_SALES = 10000;
    public static final int RATE_B_SALES = 15000;
    public static final int RATE_C_SALES = 18000;
    public static final int RATE_D_SALES = 21000;
    public static final int RATE_E_SALES = 22000;

    public static final int ADVANCE_CASH_LIMIT = 1500; 

    private String salesPersonName;
    private double salesAmountInCAD;
    private double salesCommissionRate;
    private boolean isInDebt;
    private double cashAdvance;

    /**
     * CommissionSales default Constructor
     *
     */
    public CommissionSales(){
        setSalesPersonName("");
        setSalesAmountInCAD(0);
        setCashAdvance(0);
        setIsInDebt(false);
        calculateSalesCommissionRate();
    }

    /**
     * CommissionSales Constructor
     *
     * @param newName A parameter to set salesPersonName
     * @param newSalesInCAD A parameter to set salesAmountInCAD
     */
    public CommissionSales(String newName, double newSalesInCAD,
    double newCashInAdvance){
        setSalesPersonName(newName);
        setSalesAmountInCAD(newSalesInCAD);
        setCashAdvance(newCashInAdvance);
        setIsInDebt(false);
        calculateSalesCommissionRate();
    }

    /**
     * Method getSalesPersonName
     *
     * @return  return salesPersonName
     */
    public String getSalesPersonName(){
        return salesPersonName;
    }

    /**
     * Method getsalesAmountInCAD
     *
     * @return  return salesAmountInCAD
     */
    public double getsalesAmountInCAD(){
        return salesAmountInCAD;
    }

    /**
     * Method getSalesCommissionRate
     *
     * @return  return salesCommossionRate
     */
    public double getSalesCommissionRate(){
        return salesCommissionRate;
    }

    /**
     * Method getIsInDebt
     *
     * @return  return isInDebt
     */
    public boolean getIsInDebt(){
        return isInDebt;
    }

    /**
     * Method getCashAdvance
     *
     * @return  return cashAdvance
     */
    public double getCashAdvance(){
        return cashAdvance;
    }

    /**
     * Method setSalesPersonName
     *
     * @param newName A parameter to set salesPersonName
     */
    public void setSalesPersonName(String newName){
        if(newName != null){
            salesPersonName = newName;
        }
        else {
            salesPersonName = "";
        }
    }

    /**
     * Method setsalesAmountInCAD
     *
     * @param newSalesInCAD A parameter to set salesAmountInCAD
     */
    public void setSalesAmountInCAD(double newSalesInCAD){
        if(newSalesInCAD >= 0){
            salesAmountInCAD = newSalesInCAD;
        }
    }

    /**
     * Method setIsInDebt
     *
     * @param newInDebt A parameter to set isInDebt
     */
    public void setIsInDebt(boolean newInDebt){

        isInDebt = newInDebt;
    }

    /**
     * Method setCashAdvance
     *
     * @param newCashInAdvance A parameter to set cashAdvance
     */
    public void setCashAdvance(double newCashInAdvance){
        if(newCashInAdvance >0 && newCashInAdvance <= ADVANCE_CASH_LIMIT ){
            cashAdvance = newCashInAdvance;
            setIsInDebt(true);
        }
        else{ 
            cashAdvance = 0; 
            setIsInDebt(false);
        }       
    }

    /**
     * Method calculateCommossionRate
     *
     */
    public void calculateSalesCommissionRate(){
        if(salesAmountInCAD <  RATE_A_SALES){
            salesCommissionRate = RATE_A ;    
        }
        else if(salesAmountInCAD <  RATE_B_SALES){
            salesCommissionRate = RATE_B;
        }
        else if(salesAmountInCAD <  RATE_C_SALES){
            salesCommissionRate = RATE_C ; 
        }
        else if(salesAmountInCAD <  RATE_D_SALES){
            salesCommissionRate = RATE_D ; 
        }
        else{
            salesCommissionRate = RATE_E; 
        }
    }

    /**
     * Method calculatePay
     *
     * @return The return the sales commossion payment amount
     */
    public double calculatePay(){
        return (salesAmountInCAD * salesCommissionRate) - cashAdvance ;
    }

    /**
     * Method displayDetails to dispaly the name, rate and earnings of
     * the sales person
     *
     */
    public void displayDetails(){
        if(cashAdvance>0){
            System.out.println("Sales person " +  getSalesPersonName() +
                " has the sales commission rate of " + salesCommissionRate +
                "received cash advance amount $ "+ cashAdvance +
                " .The net earnings is $ "+calculatePay() +" ."); 
        }
        else{
            System.out.println("Sales person " +  getSalesPersonName() +
                " has the sales commission rate of " + salesCommissionRate +
                " .The net earnings is $ "+calculatePay() +" ."); 
        }
    }
}

