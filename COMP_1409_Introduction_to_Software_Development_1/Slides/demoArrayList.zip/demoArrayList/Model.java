
/**
 * Model has height in inches, weight in pounds, and might travel or smoke.
 * 
 * @author Colleen
 * @version 2012.05.14
 * @version 2013.02.12
 */
public class Model
{
      public static final int IN_PER_FOOT = 12;
      public static final int BASE_RATE = 60;
      public static final int TALL_INCHES = 67;
      public static final double THIN_POUNDS = 140.0;
      public static final int TALL_THIN_BONUS = 5;
      public static final int TRAVEL_BONUS = 4;
      public static final int SMOKER_DEDUCTION = 10;
           
      private String firstName;
      private String lastName;
      private int heightInInches;
      private double weightInPounds;
      private boolean travels;
      private boolean smokes;

    /**
     * Default constructor for objects of class Model
     */
    public Model()
    {
        setFirstName("");
        setLastName("");
        setHeightInInches(0);
        setWeightInPounds(0.0);
        setTravels(false);
        setSmokes(false);
    }

    /**
     * Constructor for Model
     * @param mFirstName model's first name
     * @param mLastName model's last name
     * @param mHeightInInches model's height in inches
     * @param mWeightInPounds model's weight in pounds
     * @param mTravels does the model travel?
     * @param mSmokes does the model smoke?
     */
    public Model(String mFirstName,
                 String mLastName,
                 int mHeightInInches,
                 double mWeightInPounds,
                 boolean mTravels,
                 boolean mSmokes)
    {
        setFirstName(mFirstName);
        setLastName(mLastName);
        setHeightInInches(mHeightInInches);
        setWeightInPounds(mWeightInPounds);
        setTravels(mTravels);
        setSmokes(mSmokes);
    }
    
    /**
     * Gets the model's first name
     * @return first name
     */
    public String getFirstName()
    {
        return firstName;
    }
    
    /**
     * Gets the model's last name
     * @return last name
     */
    public String getLastName()
    {
        return lastName;
    }
    
    /**
     * Gets the model's height in inches
     * @return height in inches
     */
    public int getHeightInInches()
    {
        return heightInInches;
    }
    
    /**
     * Gets the model's weight in pounds
     * @return weight in pounds
     */
    public double getWeightInPounds()
    {
        return weightInPounds;
    }
    
    /**
     * Gets whether the model travels
     * @return travels true or false
     */
    public boolean getTravels()
    {
        return travels;
    }
    
    /**
     * Gets whether the model smokes
     * @return smokes true or false
     */
    public boolean getSmokes()
    {
        return smokes;
    }
    
    /**
     * Sets model first name
     * @param newFirstName model's new first name
     */
    public void setFirstName(String newFirstName)
    {
        if (newFirstName != null) {
            firstName = newFirstName;
        }
        else {
            if(firstName == null) {
                firstName = "";
            }
        }
    }
    
    /**
     * Sets model last name
     * @param newLastName model's new last name
     */
    public void setLastName(String newLastName)
    {
        if (newLastName != null) {
            lastName = newLastName;
        }
        else {
            if(lastName == null) {
                lastName = "";
            }
        }
    }
    
    /**
     * Sets model height in inches
     * @param newHeightInInches model's new height in inches
     */
    public void setHeightInInches(int newHeightInInches)
    {
        if(newHeightInInches >= 0) {
            heightInInches = newHeightInInches;
        }
        else {
            System.out.println("Height cannot be " + newHeightInInches);
        }
    }
    
    /**
     * Sets model weight in pounds
     * @param newWeightInPounds model's new weight in pounds
     */
    public void setWeightInPounds(double newWeightInPounds)
    {
        if(newWeightInPounds >= 0) {
            weightInPounds = newWeightInPounds;
        }
        else {
            System.out.println("Weight cannot be " + newWeightInPounds);
        }
    }
    
    /**
     * Sets travel status
     * @param doesTravel does the model travel?
     */
    public void setTravels(boolean doesTravel)
    {
        travels = doesTravel;
    }
    
    /**
     * Sets smoker status
     * @param doesSmoke does the model smoke?
     */
    public void setSmokes(boolean doesSmoke)
    {
        smokes = doesSmoke;
    }
    
    /**
     * Converts height in inches to feet and inches
     * @return height as a String
     */
    public String convertHeightToFeetInches()
    {
        int feet = heightInInches / IN_PER_FOOT;
        int remainingInches = heightInInches % IN_PER_FOOT;
        String feetAndInches = feet + " feet " + remainingInches + " inches";
        return feetAndInches;
    }
    
    /**
     * Calculates and returns pay per hour. Everyone receives
     * the hourly BASE_RATE. Tall, thin models (both tall and thin) 
     * receive an hourly bonus of TALL_THIN_BONUS. Tall means TALL_INCHES 
     * inches or more, thin means less than THIN_POUNDS pounds. 
     * Models who are willing to travel receive an extra TRAVEL_BONUS 
     * per hour. However, models who smoke have SMOKER_DEDUCTION per hour 
     * deducted from their pay.
     * @return pay per hour
     */
    public int calculatePayPerHour()
    {
        int payPerHour = BASE_RATE;
        
        // if tall and thin give the model a bonus
        if(heightInInches >= TALL_INCHES && weightInPounds < THIN_POUNDS) {
            payPerHour += TALL_THIN_BONUS;
        }
        
        // if travels give the model a bonus
        if(travels) {
            payPerHour += TRAVEL_BONUS;
        }
        
        // if smokes deduct from pay
        if(smokes) {
            payPerHour -= SMOKER_DEDUCTION;
        }
        
        return payPerHour;
    }
    
    /**
     * Displays model details on the terminal window
     */
    public void displayModelDetails()
    {
        System.out.println("Name: " + getFirstName() + " " + getLastName());
        System.out.println("Height: " + convertHeightToFeetInches());
        System.out.println("Weight: " + getWeightInPounds() + " pounds");
        System.out.println("Travels: " + getTravels() + "  Smokes: " + getSmokes());
        System.out.println("Hourly rate: $" + calculatePayPerHour());
    }
}







