import java.util.ArrayList;
/**
 * Agency - to demo ArrayList
 * 
 * @author Colleen 
 * @version 2013.02.28
 */
public class Agency
{
    private ArrayList<Model> models;
    /**
     * Constructor for objects of class Agency
     */
    public Agency()
    {
        models = new ArrayList<Model>();
    }

    /**
     * Adds a model to the agency
     * @param aModel to add
     */
    public void addModel(Model aModel)
    {
        models.add(aModel);
    }

    /**
     * Shows first and last names of all models
     */
    public void showNames()
    {
        for(Model oneModel : models){
            System.out.println(oneModel.getFirstName() + " " + oneModel.getLastName());
        }
    }

}














