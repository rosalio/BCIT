
/**
 * class to hold Student information.
 * 
 * @author (Rana Alsammarraie) 
 * @version (2014-1-5)
 */
public class Student
{
  private String studentName;
  private String studentId;
  private int studentAgeInYears;
  private boolean isFullTimeStudent;
  private double studentGrade;
  
}
