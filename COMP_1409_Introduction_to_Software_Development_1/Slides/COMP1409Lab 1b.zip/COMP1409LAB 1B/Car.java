
/**
 * Simple car simulation class.
 * 
 * @author (Rana Alsammarraie) 
 * @version (2014-1-5)
 */
public class Car
{
   
    private String carMake;
    private String carModel;
    private boolean isFrontWheelDrive;
    private double carPriceInCAD;
    private int carYearPurchased;

   
}
