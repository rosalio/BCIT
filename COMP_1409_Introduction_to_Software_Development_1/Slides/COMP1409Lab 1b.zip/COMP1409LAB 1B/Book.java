
/**
 * Simple Book simulation class.
 * 
 * @author (Rana Alsammarraie) 
 * @version (2014-1-5)
 */
public class Book
{
    private String bookTitle;
    private String bookAuthorName;
    private String isbnNumber;
    private boolean isHardCover;
    private int numberOfPages;
    private double weightInKg;
}
