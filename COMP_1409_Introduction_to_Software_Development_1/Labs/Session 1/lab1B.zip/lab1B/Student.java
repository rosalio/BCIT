
/**
 * Write a description of class Student here.
 * 
 * @author Alex Dai
 * @version Apr 9 2014
 */
public class Student
{
    // instance variables
    private String firstName;
    private String lastName;
    private String studentID;
    private String major;
    private String department;
    private String phoneNumber;
    private String emailAddress;
    private String mailingAddress;
    private String residentialAddress;
    private String emmergencyContact;
    
    private int yearOfBirth;
    private int monthOfBirth;
    private int dayOfBirth;
    
    private char gender;
    private double gpa;
    private double creditTaken;
    
    private boolean isFulltime;
    private boolean isInternational;
    /**
     * Constructor for objects of class Student
     */
    public Student()
    {
        // initialise instance variables
    
    }

}
