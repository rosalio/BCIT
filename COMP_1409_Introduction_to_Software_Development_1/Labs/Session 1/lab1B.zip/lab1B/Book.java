
/**
 * Write a description of class Book here.
 * 
 * @author Alex Dai
 * @version Apr 9, 2014
 */
public class Book
{
    // instance variables
    private String name;
    private String category;
    private String isbn;
    private String author;
    private String publisher;
    
    private int numOfPages;
    private int yearPub;
    private int monthPub;
    private int dayPub;
    private int edition;
    
    private double priceInCAD;
    private double reviewRate;
    
    private boolean isEbook;
    
    /**
     * Constructor for objects of class Book
     */
    public Book()
    {
        // initialise instance variables
        
    }
}
