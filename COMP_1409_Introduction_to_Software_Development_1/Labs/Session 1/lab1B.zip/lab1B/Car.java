
/**
 * Write a description of class Car here.
 * 
 * @author Alex Dai
 * @version Apr 9 2014
 */
public class Car
{
    // instance variables - replace the example below with your own
    
    private String maker;
    private String model;
    private String bodyType;
    private String transmission;
    private String licenseNum;
    private String ownerName;
    
    private int year;
    private int seatCapacity;
    private int numCylinders;
    
    private double horsepower;
    private double torqueLbFt;
    private double lengthInch;
    private double widthInch;
    private double heightInch;
    private double wheelBaseInch;
    private double weightLbs;
    private double engineLitre;
    private double maxSpeed;
    private double fuelCapacity;
    private double priceCAD;
    private double odometerKm;
    
    private boolean hasAbs;
    private boolean hasAccident;
    
    /**
     * Constructor for objects of class Car
     */
    public Car()
    {
        // initialise instance variables
      
    }
}
