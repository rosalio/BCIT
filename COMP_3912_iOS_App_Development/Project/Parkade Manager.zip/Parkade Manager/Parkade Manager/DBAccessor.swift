//
//  DBAccessor.swift
//  Parkade Manager
//
//  Created by Dai, Alex on 3/27/16.
//  Copyright © 2016 Dai, Alex. All rights reserved.
//

import Foundation
import UIKit
import SQLite

class DBAccessor {

    static var database: Connection?
    
    static func getDBConnection() -> Connection {
        if (database == nil) {
            let path = NSSearchPathForDirectoriesInDomains(
                .DocumentDirectory, .UserDomainMask, true
            ).first!
            database = try! Connection("\(path)/pm.sqlite3")
            
            database!.busyTimeout = 5
            
            database!.busyHandler({ tries in
                if tries >= 3 {
                    return false
                }
                return true
            })
        }
        return self.database!
    }

}

