//
//  Vehicle.swift
//  Parkade Manager
//
//  Created by Dai, Alex on 3/28/16.
//  Copyright © 2016 Dai, Alex. All rights reserved.
//

import Foundation

class Vehicle
{
    var id: Int64 = 0
    var locationId: Int64 = 0
    var checkInTime: NSDate = NSDate()
    var type: String = "type"
    var make: String = "make"
    var model: String = "model"
    var license: String = "license"
    var scannableId: String = "scannableId"
    
    init() {}
    
    init(id: Int64, locationId: Int64, checkInTime: NSDate, type: String, make: String, model: String, license: String, scannableId: String) {
        self.id = id
        self.locationId = locationId
        self.checkInTime = checkInTime
        self.type = type
        self.make = make
        self.model = model
        self.license = license
        self.scannableId = scannableId
    }
    
}