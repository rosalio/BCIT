//
//  Location.swift
//  Parkade Manager
//
//  Created by Dai, Alex on 3/27/16.
//  Copyright © 2016 Dai, Alex. All rights reserved.
//

import Foundation

class Location
{
    var id: Int64 = 0
    var code = "code"
        
    init(id: Int64, code: String) {
        self.id = id
        self.code = code
    }
    
    
    
}