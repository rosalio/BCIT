//
//  DashboardTableViewController.swift
//  Parkade Manager
//
//  Created by Dai, Alex on 3/27/16.
//  Copyright © 2016 Dai, Alex. All rights reserved.
//

import UIKit
import SQLite

class DashboardTableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var db: Connection?
    
    @IBOutlet var dashboardTableView: UITableView!
    var arrayOfLocations: [Location] = [Location]()
    var arrayOfVehicles: [Vehicle] = [Vehicle]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        db = DBAccessor.getDBConnection()
        setupLocations()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        dashboardTableView.reloadData()
        setupLocations()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func setupLocations() {
        arrayOfLocations.removeAll()
        arrayOfVehicles.removeAll()
        
        let locationTable = Table("Location")
        let vehicleTable = Table("Vehicle")
    
        let id = Expression<Int64>("id")
        let locationId = Expression<Int64>("locationId")
        let code = Expression<String>("code")
        let checkInTime = Expression<NSDate>("checkInTime")
        let type = Expression<String>("type")
        let make = Expression<String>("make")
        let model = Expression<String>("model")
        let license = Expression<String>("license")
        let scannableId = Expression<String>("scannableId")

        let locationArray = Array(try! db!.prepare(locationTable))
        for result in locationArray {
            let location = Location(id: result.get(id), code: result.get(code))
            arrayOfLocations.append(location)
        }
        
        let vehicleArray = Array(try! db!.prepare(vehicleTable))
        for result in vehicleArray {
            let vehicle = Vehicle(id: result.get(id), locationId: result.get(locationId), checkInTime: result.get(checkInTime), type: result.get(type), make: result.get(make), model: result.get(model), license: result.get(license), scannableId: result.get(scannableId))
            arrayOfVehicles.append(vehicle)
        }
        
        //let query = locationTable.join(vehicleTable, on: vehicleTable[locationId] == locationTable[id])

    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfLocations.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath) as! DashboardCell
        
        if (indexPath.row % 2 == 0) {
            cell.backgroundColor = UIColor.lightGrayColor()
        }
        
        let location = arrayOfLocations[indexPath.row]
        cell.setLocation(location)
        cell.setVehicle(arrayOfVehicles)
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let location = arrayOfLocations[indexPath.row]
        let detailViewController: DetailViewController = self.storyboard?.instantiateViewControllerWithIdentifier("DetailViewController") as! DetailViewController
     
        detailViewController.location = location
        detailViewController.setVehicle(arrayOfVehicles)

        self.navigationController?.pushViewController(detailViewController, animated: true)
    }
    
}
