//
//  ViewController.swift
//  Parkade Manager
//
//  Created by Dai, Alex on 3/25/16.
//  Copyright © 2016 Dai, Alex. All rights reserved.
//

import UIKit
import SQLite

class ViewController: UIViewController, ScannerViewDelegate {
    
    var db: Connection?
    let userTable = Table("User")
    let name = Expression<String>("name")
    let badgeId = Expression<String>("badgeId")
    
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var DBTestButton: UIButton!
    @IBOutlet weak var dashboardButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        db = DBAccessor.getDBConnection()
        DBTestButton.hidden = true
        dashboardButton.hidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "showCameraView") {
            let destination = segue.destinationViewController as! ScannerViewController
            destination.delegate = self
        }
    }
    
    @IBAction func openDashboard(sender: UIButton) {
    }
    
    func acceptScannableId(badgeIdStr : String) {
        let (isAuthorized, msg) = isUserAuthorized(badgeIdStr)
        if (isAuthorized) {
            userName.text = "Logged in as: " + msg
            dashboardButton.hidden = false
            // TODO open Dashboard view
            //self.performSegueWithIdentifier("openDashboardView", sender: self)
            
        } else {
            dashboardButton.hidden = true
            let alertController = UIAlertController(title: "Authorization", message: "Sorry! The user is not authorized to perform operation on the device!", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alertController, animated: true, completion: nil)
        }
    }
    
    func isUserAuthorized(searchBadgeId : String) -> (Bool, String) {
        let count = try! db!.scalar(userTable.filter(badgeId == searchBadgeId).count)

        if (count == 0) {
            return (false, "Unauthorized")
        } else {
            let query = userTable.select(name).filter(badgeId == searchBadgeId)
            let queryResult = try! db!.prepare(query)
            for user in queryResult {
                return (true, user[name])
            }
            return (false, "Error!")
        }
    }
    
    // This is a method for develop and debug.
    @IBAction func testDatabase(sender: UIButton) {
        let path = NSSearchPathForDirectoriesInDomains(
            .DocumentDirectory, .UserDomainMask, true
        ).first!
        
        if (db == nil) {
            db = try! Connection("\(path)/pm.sqlite3")
        }
        
        // Create Table User
        let userTable = Table("User")
        let id = Expression<Int64>("id")
        let name = Expression<String>("name")
        let badgeId = Expression<String>("badgeId")
        try! db!.run(userTable.create(ifNotExists: true) {
            t in
            t.column(id, primaryKey: .Autoincrement)
            t.column(name)
            t.column(badgeId, unique: true)
        })

        // Insert data to User Table
//        let insert = userTable.insert(name <- "Alex Dai", badgeId <- "22827")
//        let rowId = try! db.run(insert)
//        print("New user created with id: \(rowId)")


        // Create Table Location
        let locationTable = Table("Location")
        let code = Expression<String>("code")
        try! db!.run(locationTable.create(ifNotExists: true) {
            t in
            t.column(id, primaryKey: .Autoincrement)
            t.column(code, unique: true)
        })
        
        // Initialize locations
//        try! db.run(locationTable.insert(code <- "01"))
//        try! db.run(locationTable.insert(code <- "02"))
//        try! db.run(locationTable.insert(code <- "03"))
//        try! db.run(locationTable.insert(code <- "04"))
//        try! db.run(locationTable.insert(code <- "05"))
        
        
//        for location in try! db.prepare(locationTable) {
//            print("id: \(location[id]), name: \(location[code])")
//        }
        
        // Create Table Vehicle
        let vehicleTable = Table("Vehicle")
        let locationId = Expression<Int64>("locationId")
        let checkInTime = Expression<NSDate>("checkInTime")
        let type = Expression<String>("type")
        let make = Expression<String>("make")
        let model = Expression<String>("model")
        let license = Expression<String>("license")
        let scannableId = Expression<String>("scannableId")
        
//        try! db!.run(vehicleTable.drop())
        
        try! db!.run(vehicleTable.create(ifNotExists: true) {
            t in
            t.column(id, primaryKey: .Autoincrement)
            t.column(locationId)
            t.column(checkInTime)
            t.column(type)
            t.column(make)
            t.column(model)
            t.column(license)
            t.column(scannableId, unique: true)
        })
        
        
//        for vehicle in try! db!.prepare(vehicleTable) {
//            print("id: \(vehicle[id]), locationId: \(vehicle[locationId]), scannableId: \(vehicle[scannableId])")
//        }
        
//        try! db!.run(vehicleTable.insert(locationId <- Int64(1), checkInTime <- NSDate(), type <- "SUV", make <- "Mazda", model <- "CX5", license <- "618 XRJ", scannableId <- "YMS-R1-00008DWALKB2UM8D"))
//        
//        try! db!.run(vehicleTable.insert(locationId <- Int64(0), checkInTime <- NSDate(), type <- "Car", make <- "Toyota", model <- "Corolla", license <- "381 JET", scannableId <- "YMS-R1-00002Z2MU87TO350"))
//        try! db!.run(vehicleTable.insert(locationId <- Int64(0), checkInTime <- NSDate(), type <- "Car", make <- "Honda", model <- "Civic", license <- "642 KDN", scannableId <- "YMS-R1-00006XRCI46OVTGQ"))
//        try! db!.run(vehicleTable.insert(locationId <- Int64(0), checkInTime <- NSDate(), type <- "Truck", make <- "Ford", model <- "F-150", license <- "939 MDJ", scannableId <- "YMS-R1-0000K246G7MM8I5O"))
//        
        
    }
    
}

