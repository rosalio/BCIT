//
//  DashboardCell.swift
//  Parkade Manager
//
//  Created by Dai, Alex on 3/27/16.
//  Copyright © 2016 Dai, Alex. All rights reserved.
//

import UIKit

class DashboardCell: UITableViewCell {

    var locationId : Int64?
    
    @IBOutlet weak var locationCodeLabel: UILabel!
    @IBOutlet weak var vehicleTypeLabel: UILabel!
    @IBOutlet weak var vehicleMakeLabel: UILabel!
    @IBOutlet weak var vehicleModelLabel: UILabel!
    @IBOutlet weak var vehicleLicenseLabel: UILabel!
    @IBOutlet weak var checkInTime: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setLocation(location : Location) {
        self.locationId = location.id
        self.locationCodeLabel.text = location.code
    }
    
    func setVehicle(vehicles : [Vehicle]) {
        for i in 0..<vehicles.count {
            if (vehicles[i].locationId == self.locationId) {
                self.vehicleTypeLabel.text = vehicles[i].type
                self.vehicleMakeLabel.text = vehicles[i].make
                self.vehicleModelLabel.text = vehicles[i].model
                self.vehicleLicenseLabel.text = vehicles[i].license
                self.checkInTime.text = String(vehicles[i].checkInTime)
                break;
            } else {
                self.vehicleTypeLabel.text = ""
                self.vehicleMakeLabel.text = ""
                self.vehicleModelLabel.text = ""
                self.vehicleLicenseLabel.text = ""
                self.checkInTime.text = ""
            }
        }
    }
    
    
}
