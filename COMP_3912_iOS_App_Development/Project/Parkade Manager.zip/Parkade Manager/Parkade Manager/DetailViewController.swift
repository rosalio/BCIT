//
//  DetailViewController.swift
//  Parkade Manager
//
//  Created by Dai, Alex on 3/28/16.
//  Copyright © 2016 Dai, Alex. All rights reserved.
//

import UIKit
import SQLite

class DetailViewController: UIViewController, ScannerViewDelegate {
    
    var db: Connection?
    
    var operationType: String?
    var location: Location?
    var vehicle: Vehicle?
    var vehicleScannableId: String?
    
    //let locationTable = Table("Location")
    let vehicleTable = Table("Vehicle")
    
    let id = Expression<Int64>("id")
    let locationId = Expression<Int64>("locationId")
    let scannableId = Expression<String>("scannableId")
    let code = Expression<String>("code")
    let checkInTime = Expression<NSDate>("checkInTime")
    let type = Expression<String>("type")
    let make = Expression<String>("make")
    let model = Expression<String>("model")
    let license = Expression<String>("license")
    
    @IBOutlet weak var locationCodeLabel: UILabel!
    @IBOutlet weak var vehicleTypeLabel: UILabel!
    @IBOutlet weak var vehicleMakeLabel: UILabel!
    @IBOutlet weak var vehicleModelLabel: UILabel!
    @IBOutlet weak var vehicleLicenseLabel: UILabel!
    @IBOutlet weak var checkInTimeLabel: UILabel!
    @IBOutlet weak var scannableIdLabel: UILabel!
    @IBOutlet weak var checkInButton: UIButton!
    @IBOutlet weak var checkOutButton: UIButton!
    @IBOutlet weak var saveButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        db = DBAccessor.getDBConnection()
        self.locationCodeLabel.text = location!.code
        self.saveButton.hidden = true
        if (self.vehicle == nil) {
            operationType = "CHECK_IN"
        } else {
            operationType = "CHECK_OUT"
        }
        updateVehicleStatus()
        scannableIdLabel.hidden = true
    }
    
    func updateVehicleStatus() {
        if (self.vehicle != nil) {
            self.checkInButton.hidden = true
            self.checkOutButton.hidden = false
            
            self.vehicleTypeLabel.text = vehicle!.type
            self.vehicleMakeLabel.text = vehicle!.make
            self.vehicleModelLabel.text = vehicle!.model
            self.vehicleLicenseLabel.text = vehicle!.license
            self.checkInTimeLabel.text = String(vehicle!.checkInTime)
            self.scannableIdLabel.text = vehicle!.scannableId
        } else {
            self.checkInButton.hidden = false
            self.checkOutButton.hidden = true
            
            self.vehicleTypeLabel.text = ""
            self.vehicleMakeLabel.text = ""
            self.vehicleModelLabel.text = ""
            self.vehicleLicenseLabel.text = ""
            self.checkInTimeLabel.text = ""
            self.scannableIdLabel.text = ""
        }
        
        if (operationType == "CHECK_IN") {
            self.checkOutButton.hidden = true
        }
        if (operationType == "CHECK_OUT") {
            self.checkInButton.hidden = true
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func setVehicle(vehicles : [Vehicle]) {
        for i in 0..<vehicles.count {
            if (vehicles[i].locationId == self.location!.id) {
                self.vehicle = vehicles[i]
                break;
            }
        }
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "cameraViewForCheckIn" || segue.identifier == "cameraViewForCheckOut") {
            let destination = segue.destinationViewController as! ScannerViewController
            destination.delegate = self
        }
    }
    
    func acceptScannableId(tagString : String) {
        if (self.operationType == "CHECK_OUT") {
            if (self.vehicle != nil) {
                if (self.vehicle!.scannableId == tagString ) {
                    self.vehicleScannableId = self.vehicle!.scannableId
                    self.vehicle = nil
                    updateVehicleStatus()
                    self.saveButton.hidden = false
                } else {
                    let alertController = UIAlertController(title: "Error", message: "Tag does not match!", preferredStyle: UIAlertControllerStyle.Alert)
                    alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default, handler: nil))
                    self.presentViewController(alertController, animated: true, completion: nil)
                }
            }
        } else {
            if (self.vehicle == nil) {
                self.vehicleScannableId = tagString
                let query = vehicleTable.filter(scannableId == tagString)
                let queryResult = try! db!.prepare(query)
                for target in queryResult {
                    self.vehicle = Vehicle()
                    self.vehicle!.type = target[type]
                    self.vehicle!.make = target[make]
                    self.vehicle!.model = target[model]
                    self.vehicle!.license = target[license]
                    self.vehicle!.scannableId = tagString
                    break;
                }
                updateVehicleStatus()
                self.saveButton.hidden = false
            }
        }
    }

    @IBAction func saveButtonClicked(sender: UIButton) {
        if (operationType == "CHECK_IN") {
            let vehicleToCheckIn = vehicleTable.filter(scannableId == self.vehicleScannableId!)
            let currentLocationId = self.location!.id
            try! db!.run(vehicleToCheckIn.update(locationId <- currentLocationId, checkInTime <- NSDate()))
        } else {
            let vehicleToCheckOut = vehicleTable.filter(scannableId == self.vehicleScannableId!)
            try! db!.run(vehicleToCheckOut.update(locationId <- Int64(0)))
        }
        self.navigationController?.popViewControllerAnimated(true)
    }
    
}
