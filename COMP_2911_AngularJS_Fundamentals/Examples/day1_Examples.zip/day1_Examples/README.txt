
For best results run this in Firefox which bypasses the security measures taken by other browsers to stop JavaScript code from running locally. If your code does not run test it in Firefox. As well, be sure to use the Firefox debugger to:
�log your data (console.log())
�step through your code
�inspect the output that is genereated

Choose a decent IDE to write your code. You may use Visual Studio Express for Web (Free from Microsoft) or https://www.jetbrains.com/webstorm/ which is available at a decent price or Sublime.

