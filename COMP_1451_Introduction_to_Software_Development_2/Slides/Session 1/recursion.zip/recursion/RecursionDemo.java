import java.util.Scanner;
import java.util.Random;

/**
 * To demonstrate recursion, both direct and indirect.
 * 
 * A recursive method is one that calls itself. Recursion is
 * a powerful problem-solving technique if used appropriately. 
 * 
 * DO NOT use recursion unless you understand what you are doing.
 * 
 * @author Colleen 
 * @version 2013.12.08
 */
public class RecursionDemo
{
    private Scanner reader; // gets keyboard input
    private Random rand; // random number generator 
    private static int methodCounter = 0; // keep track of method calls
    /**
     * Constructor for objects of class RecursionDemo
     */
    public RecursionDemo()
    {
        reader = new Scanner(System.in);
        rand = new Random();
    }

    /**
     * To demonstrate correct use of recursion.
     * 
     * The factorial of a positive integer is the result of multiplying
     * the number by the next lowest number, continuing until you reach 1.
     * e.g. factorial of 5 is 5 * 4 * 3 * 2 * 1 which results in 120.
     * To put into recursive terms the factorial of a number is that number
     * multiplied by the factorial of the next smallest number.
     * The factorial of zero is 1. This is where the recursion stops.
     * The factorial of one is 1 * the factorial of 0
     * The factorial of two is 2 * the factorial of 1 ...
     * The factorial of five is 5 * the factorial of 4 ...
     * So for a recursive solution we first ensure that we have 
     * a positive number. Then we specify the stopping condition, where the 
     * return value does not involve a recursive call. For factorial this is
     * when the number passed in is zero. The factorial of zero is one.
     * 
     * If the input is above zero, we make a recursive call and pass the next 
     * smallest number so that eventually we will be seeking the factorial of zero. 
     * The result of this call is multiplied by the input number.
     * 
     * The key to recursion is to specifiy the stopping condition, where there is 
     * no more recursion.
     *  
     * @param number to calculate factorial on
     * @return the factorial of the input number
     */
    public int factorial(int number){
        if (number < 0) { // need a positive number
            System.out.println("number must be positive");
            return 0;
        }
        if(number == 0){ // stopping condition - no more recursion
            return 1;
        }
        else {
            return number * factorial(number -1); // recursive call
        }
    }
    
    /**
     * To demonstrate incorrect use of recursion.
     * Ask user if they want a number. If yes, get a number and ask again.
     */
    public void randomNumberPlayRecursive()
    {
        methodCounter++;  // count how many times the method is called
        System.out.print("Do you want a number? ");
        String userResponse = reader.nextLine();
        if(userResponse.equalsIgnoreCase("yes")) {
            System.out.print("Here's your number: ");
            System.out.println(rand.nextInt());
            randomNumberPlayRecursive();  // recursive call to start again - incorrect!!!
        }
        System.out.println("This method call finishing now: " + methodCounter--);
    }
    
    /**
     * To demonstrate incorrect user of recursion, indirect. This is when
     * two methods call each other.
     */
    public void randomNumberPlayRecursiveIndirect()
    {
        methodCounter++;  // count how many times the method is called        
        System.out.print("Do you want a number? ");
        String userResponse = reader.nextLine();
        if(userResponse.equals("yes")) {
            getNumber();
        }
        System.out.println("This method call finishing now: " + methodCounter--);            
    }
    
    /**
     * Gets a random number and calls back to the method that called this one.
     * This is indirect recursion and just as problematic as direct recursion.
     */
    private void getNumber()
    {
        System.out.print("Here's your number: ");
        System.out.println(rand.nextInt());
        randomNumberPlayRecursiveIndirect();
    }
    
    /**
     * To demonstrate a looping (preferred) way to repeatedly get user input
     * and generate a random number.
     */
    public void randomNumberPlayLoop()
    {
        methodCounter++;  // count how many times the method is called
        boolean playing = true;
        while(playing) {
            System.out.print("Do you want a number? ");
            String userResponse = reader.nextLine();
            if(userResponse.equalsIgnoreCase("yes")) {
                System.out.print("Here's your number: ");
                System.out.println(rand.nextInt());
            }
            else {
                playing = false;
            }
        }
        System.out.println("This method call finishing now: " + methodCounter--);        
    }
    
   
    
}
