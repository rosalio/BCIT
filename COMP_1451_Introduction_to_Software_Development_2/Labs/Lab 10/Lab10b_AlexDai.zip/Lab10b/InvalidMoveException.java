
/**
 * Write a description of class InvalidMoveException here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class InvalidMoveException extends Exception
{
    /**
     * Constructor for objects of class InvalidMoveException
     */
    public InvalidMoveException(String message)
    {
        super(message);
        System.out.println(message);
    }

}
