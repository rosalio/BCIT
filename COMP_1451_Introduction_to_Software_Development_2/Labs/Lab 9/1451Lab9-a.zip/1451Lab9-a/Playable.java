
/**
 * Write a description of interface Playable here.
 * 
 * @author Alex Dai
 * @version 11/14/2014
 */
public interface Playable
{
    /**
     * @return the playing time
     */
    public double specifyPlayingTime();
}
